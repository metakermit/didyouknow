'''
Created on 11. 1. 2012.

@author: kermit
'''
class NonExistentDataError(Exception): pass

class UnexpectedDataError(Exception): pass